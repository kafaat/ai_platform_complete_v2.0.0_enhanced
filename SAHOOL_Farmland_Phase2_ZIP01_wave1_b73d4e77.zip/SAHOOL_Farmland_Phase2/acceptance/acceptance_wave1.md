# Acceptance — Wave 1 (0001 + 0002)

Pending. Required before merge of PR #1624:
- [ ] CI green on the PR head
- [ ] Hospital review PASS on the PR head
- [ ] Lab receipt PASS on the PR head (Unified Local Lab)
- [ ] Owner approval by name for the staging rebuild of sahool-soil-service
Initial ZIP delivery does not wait for these (owner decision); the gates apply before merge and deploy.
