# ROLLBACK — SAHOOL Farmland Phase 2

الحزمة **شفرة فقط** (لا ترحيلات، لا بيانات مخزّنة بصيغة جديدة)، فالتراجع عكسُ الشفرة ثمّ إعادة النشر.

## قبل الدمج
أغلق الـPR — لا شيء يُعكَس.

## بعد الدمج
```bash
git revert -m 1 <merge-sha>        # أو: git revert <squash-sha>
git add -A && python scripts/ci/verify_all_generated.py --fix && git add -A
```
ثمّ PR بالتراجع عبر البوّابات نفسها، وإعادة بناء الخدمات المذكورة في Deploy-Effect **بموافقة المالك بالاسم**.

## على شجرة طُبِّقت فيها الرقعة يدويّاً
```bash
git apply -R --check SAHOOL_Farmland_Combined.patch && git apply -R SAHOOL_Farmland_Combined.patch
```

## أثر التراجع على البيانات
`soil_reclamation_assessments` تخزّن المنتَج كما بُني: الصفوف المكتوبة بعد الدمج قد تحمل
`provenance.lab_salinity_sodicity` ومدخلات `basis="lab_hb60"` في `interventions`. حقول JSON إضافيّة
يتجاهلها الكود السابق — لا تنظيف مطلوب، ولا تُحذَف الصفوف.
