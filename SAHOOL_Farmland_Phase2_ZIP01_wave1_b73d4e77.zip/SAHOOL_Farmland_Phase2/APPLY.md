# APPLY — SAHOOL Farmland Phase 2

> **لا تُطبَّق هذه الحزمة مباشرةً على الإنتاج.** مصدر الحقيقة هو الفرع المذكور في `manifest.json`؛
> هذا الـZIP مُصدَّر منه. المسار المعتمد: PR → CI أخضر → مراجعة المستشفى → إيصال المختبر → دمج →
> إعادة بناء بموافقة المالك بالاسم (Deploy-Effect في متن الـPR).

## 1. التحقّق قبل التطبيق
```bash
sha256sum -c SHA256SUMS
git checkout "$(cat BASE_SHA)"          # أو فرعٌ يحتوي BASE_SHA
git apply --check SAHOOL_Farmland_Combined.patch
```

## 2. التطبيق
- **المجمَّع (المُوصى به):** `git apply --index SAHOOL_Farmland_Combined.patch` — يشمل الشفرة والمخرجات المُعاد توليدها.
- **رقعة مجالٍ منفردة:** `git am patches/000N-*.patch` بالترتيب (0001 قبل 0002 لأنّ 0002 يستهلك سجلّ 0001)،
  **ثمّ** أعد توليد المخرجات الرسميّة — رقع المجالات لا تحمل المخرجات المولَّدة عمداً:
  ```bash
  git add -A && python scripts/ci/verify_all_generated.py --fix && git add -A
  python scripts/ci/verify_all_generated.py && python scripts/release/validate_release_package.py
  ```

## 3. التحقّق بعد التطبيق
```bash
bash scripts/ci/preflight.sh --fast
python -m pytest -q services/soil-service/test_soil_standards_compliance.py \
  services/soil-service/test_soil_land_quality.py services/soil-service/test_soil_p3_products.py
python scripts/ci/railway_deploy_impact.py --base origin/main   # يجب أن يطابق Deploy-Effect المُعلَن
```

## 4. ما لا تفعله هذه الحزمة
لا ترحيلات قاعدة بيانات · لا مسارات HTTP جديدة · لا تغيير في عقود `shared/` · لا متغيّرات Railway.
