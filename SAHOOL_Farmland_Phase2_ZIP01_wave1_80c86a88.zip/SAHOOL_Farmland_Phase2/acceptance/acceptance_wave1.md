# Acceptance — Wave 1 (0001 + 0002)

Accepted and merged: PR #1624, squash `5338b010110764b2e83ab8abaf17c0c75d4a2ea1` on main (parent `f834f4ec`), pinned to the tested head `80c86a88632383daecdc50da1f043e6a0774c4e9`. The merge tree `7d4091ed` equals the tested head's tree.

- [x] CI green on the head 80c86a88 (all checks; `runtime-stack-e2e-chaos` skipped as usual)
- [x] Hospital review PASS on the head 80c86a88. Earlier rounds: d1e81c8b FAIL, fixed in e85f5699 and ca5e0df9; b73d4e77 FAIL on a date-dependent test, fixed in 40dbf135.
- [x] Lab receipt 1624-v2 PASS on the head 80c86a88 (Unified Local Lab), including faked-clock runs on 2027-02-01 and 2031-01-01
- [x] Owner approval (2026-11-25) for a staging-only rebuild of sahool-soil-service, conditional on the three items above. No production change and no migration.

Post-merge: the staging rebuild log lines are requested from the hospital (read-only).
Wave 2 (0003, Codex, PR #1621) is not in this ZIP yet. It joins ZIP 01 once its engine moves out of `shared/` and it passes its own gates.
