# Crop suitability — measured divergence between the existing implementations (main 7551198a)

Read-only measurement, 2026-11-25. No code changed. Precondition for the owner's directive
"unify the four implementations gradually, with old-vs-new compatibility tests".

## The four implementations
| # | Path | Model | Crops |
|---|---|---|---|
| 1 | services/sahool-platform/core/engines/suitability.py:96 | Generic gate funnel (governing knock-out + weighted fuzzy modifiers → S1/S2/S3/N) | caller-supplied factors (no table) |
| 2 | services/sahool-platform/api/crop_suitability.py:93 | Weighted score: pH 0.25, EC 0.35, rain 0.20, temp 0.20 | wheat, barley, sorghum, date_palm, tomato, potato, onion, alfalfa |
| 3 | services/sahool-platform/core/variety_suitability.py:51 | Per-variety salinity (Maas–Hoffman) | varieties |
| 4 | services/soil-service/soil_science.py:160 | pH/EC/texture profile score | wheat, sorghum, tomato, date_palm, coffee |

## Threshold disagreements for the same crop
| Crop | #2 ec_max | #4 ec_max | drought_resilience THRESHOLD_ECE | #2 pH tolerable | #4 pH tolerable |
|---|---|---|---|---|---|
| sorghum | 6.5 | 8.0 | 6.8 | (5.0, 8.5) | (5.0, 8.5) |
| date_palm | 12.0 | 12.0 | — | (6.0, 9.0) | (6.5, 9.0) |
| wheat | 6.0 | 6.0 | 6.0 | (5.5, 8.5) | (5.5, 8.5) |
| tomato | 2.5 | 2.5 | 2.5 | (5.5, 7.5) | (5.5, 7.5) |

## Verdict divergence on a shared grid (#2 vs #4)
Grid: 4 common crops × pH {5.0, 5.8, 6.5, 7.2, 8.0, 8.6} × ECe {0.5, 2, 4, 6.2, 7, 9, 13} = 168 points
(ratings mapped to S1/S2/S3/N).
- Class disagreements: **30 / 168 (18%)**: sorghum 10, date palm 9, wheat 7, tomato 4.
- Usable-vs-unsuitable flips: **10**.
  - Date palm, pH 6.5: #2 "excellent" (0.88) vs #4 "unsuitable" (0.0) at every EC level. The pH lower bound and the boundary semantics differ.
  - Sorghum, ECe 7.0: #2 "unsuitable" (ec_max 6.5) vs #4 "weak" (ec_max 8.0).

## Implication
The same field and crop can get opposite advice depending on which service answers. Unification needs
**one cited tolerance table** (e.g. Maas–Hoffman thresholds, FAO-29 Rev.1 Table 4), with explicit boundary
semantics, consumed by all four. Owner decision needed: which reference is canonical, and whether the
canonical table lives in the standards registry (soil-service) or is duplicated per service
(sahool-platform cannot import soil-service).
